    Solana Tamagotchi - Full bundle

    Contains a starter React/Vite project, client-side generative pet system, adventure generator,
    simple battle component, plus generated 32x32 pixel sprites and 32x32 modular tiles.

Quick start:
  npm install
  npm run dev

Sprites are in /assets/sprites and tiles in /assets/tiles
